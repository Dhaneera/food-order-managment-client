(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/dd92d_modules_@tanstack_query-devtools_build_DevtoolsPanelComponent_LFXA4CB4_caf696.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/dd92d_modules_@tanstack_query-devtools_build_DevtoolsPanelComponent_LFXA4CB4_caf696.js",
  "chunks": [
    "static/chunks/node_modules_@tanstack_query-devtools_build_1e9e0c._.js"
  ],
  "source": "dynamic"
});
