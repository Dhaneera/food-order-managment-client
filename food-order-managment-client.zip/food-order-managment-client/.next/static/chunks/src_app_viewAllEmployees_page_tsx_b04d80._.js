(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_viewAllEmployees_page_tsx_b04d80._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_viewAllEmployees_page_tsx_b04d80._.js",
  "chunks": [
    "static/chunks/a480a_tailwind-merge_dist_lib_983356._.js",
    "static/chunks/node_modules_@nextui-org_shared-utils_dist_fcc095._.js",
    "static/chunks/node_modules_framer-motion_dist_es_6a62f5._.js",
    "static/chunks/node_modules_axios_lib_c4c49c._.js",
    "static/chunks/node_modules_737d88._.js",
    "static/chunks/src_app_473418._.js",
    "static/chunks/node_modules_@nextui-org_dom-animation_dist_index_mjs_5e59b1._.js"
  ],
  "source": "dynamic"
});
