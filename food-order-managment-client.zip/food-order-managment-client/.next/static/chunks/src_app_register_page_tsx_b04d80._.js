(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_register_page_tsx_b04d80._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_register_page_tsx_b04d80._.js",
  "chunks": [
    "static/chunks/node_modules_591f03._.js",
    "static/chunks/src_app_951d67._.js"
  ],
  "source": "dynamic"
});
