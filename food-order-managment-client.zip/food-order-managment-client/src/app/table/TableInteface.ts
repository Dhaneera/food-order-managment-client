 export default interface tableInterface {
    width: string,
    text : string,
    style: string,
 }