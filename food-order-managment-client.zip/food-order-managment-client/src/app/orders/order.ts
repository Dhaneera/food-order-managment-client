export interface orderMobile{
    id: string,
    price: number,
    orderRecDate: string,
    status: string
}